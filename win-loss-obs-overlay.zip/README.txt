OBS Win/Loss overlay
1. Upload index.html and control.html to a static hosting service.
2. Put the URL of index.html in OBS -> Sources -> Browser.
3. Set width 1920, height 1080 and enable transparent background if your OBS version shows that option.
4. Open control.html in a normal browser. Use +WIN / +LOSS to update the overlay.
5. You can also start with numbers using index.html?w=12&l=5
